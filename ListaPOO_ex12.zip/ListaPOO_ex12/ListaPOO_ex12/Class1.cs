﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListaPOO_ex12
{
    internal class TrianguloRetangulo
    {
        // Atributos
        private double ladoA;
        private double ladoB;
        private double ladoC;
        private string resultado;

        // Métodos de Acesso (Setters)
        public void setLados(double a, double b, double c)
        {
            this.ladoA = a;
            this.ladoB = b;
            this.ladoC = c;
        }

        // Métodos de Acesso (Getter)
        public string getResultado()
        {
            return resultado;
        }

        // Método de Processamento
        public void processarVerificacao()
        {
            // Ordena os lados para que o maior seja sempre a hipotenusa (c)
            double[] lados = { ladoA, ladoB, ladoC };
            Array.Sort(lados);
            double cateto1 = lados[0];
            double cateto2 = lados[1];
            double hipotenusa = lados[2];

            // Verifica se a soma dos quadrados dos catetos é igual ao quadrado da hipotenusa
            // Usando Math.Pow para elevar ao quadrado e uma pequena margem de erro
            if (Math.Pow(cateto1, 2) + Math.Pow(cateto2, 2) == Math.Pow(hipotenusa, 2))
            {
                resultado = "Os valores formam um triângulo retângulo.";
            }
            else
            {
                resultado = "Os valores NÃO formam um triângulo retângulo.";
            }
        }
    }
}
