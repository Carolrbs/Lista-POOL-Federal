﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListaPOO_ex12
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Cria um objeto da classe TrianguloRetangulo
            TrianguloRetangulo meuTriangulo = new TrianguloRetangulo();

            #region Entrada de Dados
            Console.WriteLine("Digite o valor do primeiro lado (A):");
            double a = double.Parse(Console.ReadLine());

            Console.WriteLine("Digite o valor do segundo lado (B):");
            double b = double.Parse(Console.ReadLine());

            Console.WriteLine("Digite o valor do terceiro lado (C):");
            double c = double.Parse(Console.ReadLine());

            meuTriangulo.setLados(a, b, c);
            #endregion

            #region Processamento e Saída
            // Executa a verificação
            meuTriangulo.processarVerificacao();

            // Exibe o resultado final
            Console.WriteLine("Resultado: {0}", meuTriangulo.getResultado());
            #endregion
        }
    }
}
