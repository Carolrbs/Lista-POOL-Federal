﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListaPOO_ex5
{
    internal class Program
    {
        static void Main(string[] args)
        { //Sabendo que uma milha marítima equivale a um mil, oitocentos e cinquenta e dois metros e que um quilômetro possui mil metros, fazer um programa para converter milhas marítimas em quilômetros.
            Conversor c1 = new Conversor();

            #region
            Console.Write("Digite a distância em milhas marítimas: ");
            c1.setMilhasMaritimas(double.Parse(Console.ReadLine()));
            #endregion

            #region
            c1.converterParaQuilometros();
            #endregion

            #region
            Console.WriteLine("O valor de {0} milhas marítimas equivale a {1} quilômetros.", c1.getMilhasMaritimas(), c1.getQuilometros());
            #endregion
        }
    }
}