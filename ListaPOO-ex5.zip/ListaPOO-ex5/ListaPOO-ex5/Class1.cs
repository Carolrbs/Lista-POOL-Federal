﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListaPOO_ex5
{
    internal class Conversor
    {   private double milhasMaritimas;
        private double quilometros;

        public void setMilhasMaritimas(double milhas)
        {
            this.milhasMaritimas = milhas;
        }

        public double getMilhasMaritimas()
        {
            return milhasMaritimas;
        }

        public double getQuilometros()
        {
            return quilometros;
        }

        // Método de Conversão
        public void converterParaQuilometros()
        {
            // 1 milha marítima = 1852 metros
            // 1 quilômetro = 1000 metros
            // Para converter de milhas para quilômetros, a fórmula é:
            // (milhas * 1852) / 1000
            quilometros = (milhasMaritimas * 1852) / 1000;
        }
    }
}

