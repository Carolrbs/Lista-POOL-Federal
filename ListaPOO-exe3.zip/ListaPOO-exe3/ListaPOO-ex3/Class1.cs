﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListaPOO_ex3
{
    internal class Quadrado
    {
        //Atributos
        private double diagonal;
        private double area;
        //Métodos de acesso
        public void setDiagonal(double diagonal)
        {
            this.diagonal = diagonal;
        }
        public double getDiagonal()
        {
            return diagonal;
        }
        public double getArea()
        {
            return area;
        }
        //Método de cálculo
        public void calcularAreaPelaDiagonal()
        {
            area = (diagonal * diagonal) / 2;
        }
    }
    
    
}
