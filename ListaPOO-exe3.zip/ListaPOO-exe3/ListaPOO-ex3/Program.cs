﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListaPOO_ex3
{
    internal class Program //interface
    {
        static void Main(string[] args)
        {

            Quadrado q1 = new Quadrado();

            #region Entrada
            Console.WriteLine("Digite o valor da diagonal do quadrado:");
            q1.setDiagonal(double.Parse(Console.ReadLine()));
            #endregion

            #region Processo
            q1.calcularAreaPelaDiagonal();
            #endregion

            #region Saída
            Console.WriteLine("A área do quadrado com diagonal {0} é {1}.", q1.getDiagonal(), q1.getArea());
            #endregion
        }
    }
}
