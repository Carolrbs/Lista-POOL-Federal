﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListaPOO_ex9
{
    internal class CalculadoraIMC
    {
        private double peso;
        private double altura;
        private double imc;
        private string mensagem;

        // Métodos de Acesso (Setters)
        public void setPeso(double p)
        {
            this.peso = p;
        }

        public void setAltura(double a)
        {
            this.altura = a;
        }

        // Métodos de Acesso (Getters)
        public double getImc()
        {
            return imc;
        }

        public string getMensagem()
        {
            return mensagem;
        }

        // Método de Processamento
        public void processarIMC()
        {
            // 1. Calcula o IMC
            // A fórmula é: peso / (altura * altura)
            if (altura > 0)
            {
                imc = peso / (altura * altura);
            }
            else
            {
                // Evita divisão por zero caso a validação no Main falhe
                imc = 0;
            }

            // 2. Classifica o IMC e define a mensagem
            if (imc < 20)
            {
                mensagem = "Abaixo do peso";
            }
            else if (imc >= 20 && imc < 25)
            {
                mensagem = "Peso Ideal";
            }
            else
            {
                mensagem = "Acima do peso";
            }
        }
    }
}




