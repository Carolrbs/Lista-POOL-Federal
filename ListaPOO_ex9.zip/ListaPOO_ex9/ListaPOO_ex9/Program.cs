﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListaPOO_ex9
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Cria um objeto da classe CalculadoraIMC
            CalculadoraIMC calculadora = new CalculadoraIMC();

            #region Entrada de Dados
            Console.WriteLine("Digite o seu peso em kg:");
            calculadora.setPeso(double.Parse(Console.ReadLine()));

            Console.WriteLine("Digite a sua altura em metros:");
            calculadora.setAltura(double.Parse(Console.ReadLine()));
            #endregion

            #region Processamento
            // Executa o cálculo e a classificação
            calculadora.processarIMC();
            #endregion

            #region Saída de Dados
            Console.WriteLine("-----------------------------");
            Console.WriteLine("Seu IMC é: {0:F2}", calculadora.getImc());
            Console.WriteLine("Situação: {0}", calculadora.getMensagem());
            Console.WriteLine("-----------------------------");
            #endregion
        }
    }
}
