﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListaPOO_ex6
{
    internal class Program
    {
        static void Main(string[] args)
        { //obj: Entrar via teclado com o valor da cotação do dólar e uma certa quantidade de dólares. Calcular e exibir o valor correspondente em Reais (R$).

            dollarParaReal conversor = new dollarParaReal();

            #region Entrada de Dados
            Console.WriteLine("Digite o valor da cotação do dólar (R$):");
            conversor.setCotacaoDolar(double.Parse(Console.ReadLine()));

            Console.WriteLine("Digite a quantidade de dólares a ser convertida:");
            conversor.setQuantidadeDolares(double.Parse(Console.ReadLine()));
            #endregion

            #region Processamento
            conversor.converterParaReais();
            #endregion

            #region Saída de Dados
            Console.WriteLine("O valor de {0} dólares na cotação de R${1} equivale a R${2}.",
                conversor.getQuantidadeDolares(),
                conversor.getCotacaoDolar(),
                conversor.getValorEmReais());
            #endregion
        }
    }
}
