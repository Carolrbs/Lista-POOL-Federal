﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListaPOO_ex6
{
    internal class dollarParaReal
    {
        private double cotacaoDolar;
        private double quantidadeDolares; // Corrigido o nome da variável
        private double valorEmReais;

        // Métodos de Acesso (Getters e Setters)
        public void setCotacaoDolar(double cotacao)
        {
            this.cotacaoDolar = cotacao;
        }

        public double getCotacaoDolar()
        {
            return cotacaoDolar;
        }

        public void setQuantidadeDolares(double quantidade)
        {
            this.quantidadeDolares = quantidade;
        }

        public double getQuantidadeDolares()
        {
            return quantidadeDolares;
        }

        public double getValorEmReais()
        {
            return valorEmReais;
        }

        // Método de Conversão
        public void converterParaReais()
        {
            // O valor em reais é a quantidade de dólares multiplicada pela cotação
            valorEmReais = quantidadeDolares * cotacaoDolar;
        }
    }
}
