﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListaPOO_ex8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Retangulo retangulo = new Retangulo();

            #region Entrada de Dados
            Console.WriteLine("Digite o valor da base do retângulo:");
            retangulo.setBase(double.Parse(Console.ReadLine()));

            Console.WriteLine("Digite o valor da altura do retângulo:");
            retangulo.setAltura(double.Parse(Console.ReadLine()));
            #endregion

            #region Processamento
            // Executa o cálculo e a validação
            retangulo.processarAreaEValidacao();
            #endregion

            #region Saída de Dados
            Console.WriteLine("A área do retângulo é: {0}", retangulo.getArea());
            Console.WriteLine("Mensagem: {0}", retangulo.getMensagem());
            #endregion
        }
    }
}
