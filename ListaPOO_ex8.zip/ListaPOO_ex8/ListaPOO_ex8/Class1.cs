﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListaPOO_ex8
{
    internal class Retangulo
    {
        private double baseRetangulo;
        private double alturaRetangulo;
        private double area;
        private string mensagem;

        // Métodos de Acesso (Setters)
        public void setBase(double b)
        {
            this.baseRetangulo = b;
        }

        public void setAltura(double a)
        {
            this.alturaRetangulo = a;
        }

        // Métodos de Acesso (Getters)
        public double getArea()
        {
            return area;
        }

        public string getMensagem()
        {
            return mensagem;
        }

        // Método de Processamento
        public void processarAreaEValidacao()
        {
            // 1. Calcula a área
            area = baseRetangulo * alturaRetangulo;

            // 2. Valida a área e define a mensagem
            if (area > 100)
            {
                mensagem = "Terreno grande";
            }
            else
            {
                mensagem = "Terreno pequeno";
            }
        }
    }
}
