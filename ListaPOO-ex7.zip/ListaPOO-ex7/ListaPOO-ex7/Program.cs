﻿using ListaPOO_ex8;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListaPOO_ex7
{
        internal class Program
        {
            static void Main(string[] args)
            {
                // Cria um objeto da classe ComparadorComValidacao
                ComparadorComValidacao comparador = new ComparadorComValidacao();

                #region Entrada de Dados
                Console.WriteLine("Digite o primeiro valor:");
                double v1 = double.Parse(Console.ReadLine());

                Console.WriteLine("Digite o segundo valor:");
                double v2 = double.Parse(Console.ReadLine());

                comparador.setValores(v1, v2);
                #endregion

                #region Processamento
                comparador.processarComparacao();
                #endregion

                #region Saída de Dados
                Console.WriteLine(comparador.getResultado());
                #endregion
            }
        }
    
}
