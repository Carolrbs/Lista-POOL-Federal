﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListaPOO_ex8
{
    internal class ComparadorComValidacao
    {
        // Atributos
        private double valor1;
        private double valor2;
        private string resultado;

        // Métodos de Acesso (Setters)
        public void setValores(double v1, double v2)
        {
            this.valor1 = v1;
            this.valor2 = v2;
        }

        // Método de Acesso (Getter) para o resultado
        public string getResultado()
        {
            return resultado;
        }

        // Método de Processamento
        public void processarComparacao()
        {
            if (valor1 > valor2)
            {
                resultado = $"O maior valor é: {valor1}";
            }
            else if (valor2 > valor1)
            {
                resultado = $"O maior valor é: {valor2}";
            }
            else
            {
                resultado = "Os números são idênticos.";
            }
        }
    }
}
