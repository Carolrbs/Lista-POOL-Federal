﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListaPOO_exe10
{
    internal class Program
    {
        static void Main(string[] args)
        {// Cria um objeto da classe Triangulo
            Triangulo meuTriangulo = new Triangulo();

            #region Entrada de Dados
            Console.WriteLine("Digite o valor do lado A:");
            double a = double.Parse(Console.ReadLine());

            Console.WriteLine("Digite o valor do lado B:");
            double b = double.Parse(Console.ReadLine());

            Console.WriteLine("Digite o valor do lado C:");
            double c = double.Parse(Console.ReadLine());

            meuTriangulo.setLados(a, b, c);
            #endregion

            #region Processamento e Saída
            // Executa a validação e a classificação
            meuTriangulo.processarTriangulo();

            // Exibe o resultado final
            Console.WriteLine("Resultado: {0}", meuTriangulo.getClassificacao());
            #endregion
        }
    }
}
