﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListaPOO_exe10
{
    internal class Triangulo
    {
        // Atributos
        private double ladoA;
        private double ladoB;
        private double ladoC;
        private string classificacao;

        public void setLados(double a, double b, double c)
        {
            this.ladoA = a;
            this.ladoB = b;
            this.ladoC = c;
        }

        // Métodos de Acesso (Getter)
        public string getClassificacao()
        {
            return classificacao;
        }

        public void processarTriangulo()
        {
            // 1. Verifica se os lados podem formar um triângulo
            if (ladoA + ladoB > ladoC && ladoA + ladoC > ladoB && ladoB + ladoC > ladoA)
            {
                if (ladoA == ladoB && ladoB == ladoC)
                {
                    classificacao = "Triângulo Equilátero";
                }
                else if (ladoA == ladoB || ladoA == ladoC || ladoB == ladoC)
                {
                    classificacao = "Triângulo Isósceles";
                }
                else
                {
                    classificacao = "Triângulo Escaleno";
                }
            }
            else
            {
                // Se não formam um triângulo
                classificacao = "Não é um triângulo";
            }
        }
    }
}