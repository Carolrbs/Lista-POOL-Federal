﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListaPoo_exe2
{
    internal class Quadrado
    { // Atributos (campos)
        private double lado;
        private double area;

        // Métodos de acesso (getters e setters)
        public void setLado(double lado)
        {
            this.lado = lado;
        }

        public double getLado()
        {
            return this.lado;
        }

        public double getArea()
        {
            return this.area;
        }

        // Método de processamento
        public void calcularArea()
        {
            this.area = this.lado * this.lado;
        }
    }
}
