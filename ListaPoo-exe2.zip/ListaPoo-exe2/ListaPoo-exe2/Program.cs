﻿using System;

namespace ListaPoo_exe2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Instancia a classe Quadrado
            Quadrado q1 = new Quadrado();

            #region Entrada
            Console.WriteLine("Digite o valor do lado do quadrado:");
            q1.setLado(double.Parse(Console.ReadLine()));
            #endregion

            #region Processo
            q1.calcularArea();
            #endregion

            #region Saída
            Console.WriteLine("A área do quadrado de lado {0} é {1}.", q1.getLado(), q1.getArea());
            #endregion
        }
    }

    
    

}
